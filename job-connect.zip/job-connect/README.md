# 💼 Job Connect - Node.js Job Portal Backend

## 🔧 Description
Job Connect is a backend system built with Node.js, Express, and MongoDB that powers a job search and recruitment web application. It handles user authentication, job listings, and saved jobs.

## 🚀 Features
- User registration and login
- Job posting schema
- Saved jobs for users
- MongoDB integration using Mongoose

## 🧪 Technologies Used
- Node.js
- Express
- MongoDB
- Mongoose
- Jade (for views)
- Morgan (logger)
- Cookie Parser

## 🛠️ Setup Instructions

1. Clone the repo:
```bash
git clone https://github.com/your-username/job-connect.git
cd job-connect
```

2. Install dependencies:
```bash
npm install
```

3. Start MongoDB and run:
```bash
node app.js
```

## 🗃️ Folder Structure

```
models/         # Mongoose schemas
routes/         # Express routes
views/          # Jade templates
public/         # Static assets
```

## 📫 Contact
- Name: Your Name
- Email: your.email@example.com
